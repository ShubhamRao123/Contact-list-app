package com.inmovies.mycontactlist;

public class SOLException {
}
